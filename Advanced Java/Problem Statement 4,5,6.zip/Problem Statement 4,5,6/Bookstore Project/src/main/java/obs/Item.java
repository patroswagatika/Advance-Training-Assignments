package obs;

public class Item {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
