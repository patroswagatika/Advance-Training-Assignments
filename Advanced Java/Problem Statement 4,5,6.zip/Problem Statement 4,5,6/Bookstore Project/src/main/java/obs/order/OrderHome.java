package obs.order;

public class OrderHome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
