package obs;

public class Customer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
