package obs.order;

public class Order {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
